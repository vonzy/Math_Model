% C1_1
A=load('shuju.mat');
node1=A{1};
node2=A{2};