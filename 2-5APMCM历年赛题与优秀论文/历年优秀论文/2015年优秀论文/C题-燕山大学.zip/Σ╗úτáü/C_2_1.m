clear;clc
clear;clc;close
A=load('BioD.mat');
%P=100;
B=[];
B(:,1)=A.node1;
B(:,2)=A.node2;

%intersect()
%uinon()